# Continuata Bridge

A lightweight cross-platform desktop tray application that bridges the Continuata web download UI and the local file system for browsers that block the File System Access API (Safari, Firefox).

## Why the Bridge?

Chrome and Edge can write files directly to disk via the File System Access API. Safari and Firefox cannot, and they also **block HTTPS→HTTP mixed-content requests** — even for localhost. The Bridge solves both problems:

- Receives download manifests from continuata.io over a secure HTTPS localhost connection.
- Downloads, verifies, and writes files directly to your chosen folder.
- Sends real-time progress back to the browser via WebSocket.

## Browser Support

| Browser | Needs Bridge? | Notes |
|---------|:-------------:|-------|
| Chrome (desktop) | No | File System Access API |
| Edge (desktop) | No | File System Access API |
| Safari | **Yes** | Requires bridge + HTTPS |
| Firefox | **Yes** | Requires bridge + HTTPS |
| Chrome (Android/iOS) | No | OPFS fallback in web app |
| Safari (iOS) | **Yes** | Requires bridge + HTTPS |

## Installation

### Download a Pre-built Release (recommended)

1. Go to the [Releases](https://github.com/stukennedy/continuata-bridge/releases) page.
2. Download the package for your platform:
   | Platform | File |
   |----------|------|
   | macOS (Apple Silicon) | `continuata-bridge_darwin_arm64.tar.gz` |
   | macOS (Intel) | `continuata-bridge_darwin_amd64.tar.gz` |
   | Windows | `continuata-bridge_windows_amd64.zip` |
   | Linux | `continuata-bridge_linux_amd64.tar.gz` |
3. Extract and launch — a Continuata icon appears in the system tray/menu bar.

### Build from Source

**Prerequisites:** Go 1.22+, `make`

```bash
git clone https://github.com/stukennedy/continuata-bridge.git
cd continuata-bridge
make deps   # go mod tidy && go mod download
make build  # outputs build/continuata-bridge
```

Cross-compile example:
```bash
GOOS=linux GOARCH=amd64 make build
```

## Setup: HTTPS (required for Safari & Firefox)

Safari and Firefox only allow HTTPS pages to contact HTTPS local servers — not HTTP. The Bridge automatically generates a locally-trusted certificate on first launch so it can serve `https://127.0.0.1:8765`. No external tools required.

### Automatic (default)

1. Launch the Bridge.
2. On first run, it generates a local Certificate Authority and localhost certificate.
3. You will be prompted for your system password to trust the CA — this is a one-time step.
4. The tray menu shows **✓ HTTPS Enabled** when ready.

On subsequent launches, the existing certificates are reused automatically — no password prompt needed.

### Manual (if auto-setup was cancelled)

Click **⚠ Enable HTTPS (required for Safari/Firefox)** in the tray menu. The Bridge will regenerate certificates and prompt for your password again.

### Certificate Location

Certs are stored in platform-specific directories:

| Platform | Path |
|----------|------|
| macOS | `~/Library/Application Support/Continuata Bridge/certs/` |
| Windows | `%APPDATA%\Continuata Bridge\certs\` |
| Linux | `~/.local/share/Continuata Bridge/certs/` |

## Usage

1. **Launch** the Bridge — the tray icon appears.
2. The server **starts automatically** on port 8765.
3. Open [continuata.io](https://continuata.io) in Safari or Firefox.
4. The page detects the Bridge and proceeds with the download automatically.

### Tray Menu

| Item | Description |
|------|-------------|
| Status | Current server state (Ready / Running on port XXXX / Error) |
| Start / Stop Server | Manually control the server |
| Change Download Path… | Choose where files are saved (default: `~/Downloads/Continuata`) |
| ✓ HTTPS Enabled *(or)* ⚠ Enable HTTPS | HTTPS status / trigger manual setup |
| Quit | Exit the application |

## API Reference

The Bridge listens on `127.0.0.1:8765` (HTTP or HTTPS). All endpoints return JSON.

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Returns `{status, version, time, tls}`. Used for bridge detection. |
| `GET` | `/info` | Returns `{downloadPath, status}`. |
| `POST` | `/download` | Start a download. Body: `{token, manifest, apiBaseURL?, downloadPath?}` |
| `GET` | `/progress` | Current download progress snapshot. |
| `POST` | `/pause` | Pause the active download. |
| `POST` | `/resume` | Resume a paused download. |
| `POST` | `/cancel` | Cancel the active download. |
| `GET` | `/ws` | WebSocket — streams `ProgressUpdate` JSON messages in real time. |

### WebSocket Progress Message

```json
{
  "type": "progress",
  "percent": 42.5,
  "bytesDownloaded": 44040192,
  "totalBytes": 103809024,
  "currentFile": "Samples/kick.wav",
  "fileProgress": 80.0,
  "speed": 8388608,
  "eta": 7,
  "activeConnections": 4,
  "isPaused": false
}
```

## Configuration

| Environment Variable | Default | Description |
|----------------------|---------|-------------|
| `BRIDGE_PORT` | `8765` | Listen port |
| `BRIDGE_DOWNLOAD_PATH` | `~/Downloads/Continuata` | Default download directory |
| `BRIDGE_MAX_CONNECTIONS` | `4` | Concurrent chunk/pack downloads |
| `BRIDGE_ALLOWED_ORIGINS` | *(see below)* | Comma-separated CORS/WS origin override |
| `BRIDGE_TLS_CERT` | — | Path to TLS certificate (overrides auto-discovery) |
| `BRIDGE_TLS_KEY` | — | Path to TLS private key (overrides auto-discovery) |
| `BRIDGE_DEBUG_CORS` | `false` | Verbose CORS/origin logging (`1`, `true`, or `yes`) |

### Default Allowed Origins

When `BRIDGE_ALLOWED_ORIGINS` is not set the Bridge allows:
- `https://continuata.io`, `https://www.continuata.io`, `https://continuata.com`
- Any subdomain of `.continuata.io`, `.continuata.com`
- Any Cloudflare preview URL (`*.workers.dev`, `*.pages.dev`)
- Local dev servers: `http(s)://localhost:5173`, `http(s)://localhost:8787`

## Security

- **Localhost only** — binds to `127.0.0.1`; never reachable from other machines.
- **Origin allowlist** — CORS and WebSocket `Origin` header checked against an explicit allowlist; requests from unlisted origins are rejected.
- **Private Network Access** — responds to Chrome's PNA preflight (`Access-Control-Request-Private-Network: true`) so the page can contact localhost from HTTPS.
- **SHA-256 verification** — every downloaded chunk and V3 pack is verified before being written to disk.
- **No credential storage** — no passwords, tokens, or API keys are persisted.

## Development

### Project Layout

```
continuata-bridge/
├── main.go                  # Tray bootstrap, lifecycle, menu actions
├── server.go                # HTTP/WebSocket server and endpoints
├── downloader.go            # Chunked & pack downloads, verification
├── downloader_test.go       # Unit tests
├── downloader_v3_test.go    # V3 pack integration tests (httptest.Server)
├── server_test.go           # Server unit tests
├── paths_*.go               # Platform-specific cert/data paths
├── ui_*.go                  # Platform-specific dialogs/notifications
├── assets/                  # Source icons
└── .github/workflows/       # CI: test, lint, GoReleaser publish
```

### Commands

```bash
make deps    # Sync Go modules
make build   # Build for current platform → build/continuata-bridge
make run     # Build and run
make test    # go test -v ./...
make lint    # golangci-lint
make icons   # Regenerate icons from assets/icon.svg
```

### Branching Workflow

See [CLAUDE.md](CLAUDE.md) for the full workflow. In short:

1. Branch from `staging`: `git checkout -b feat/<issue>-<slug>`
2. Open a PR → `staging`
3. `staging` is merged into `main` for releases.
4. Tag `main` to trigger GoReleaser: `git tag v1.2.3 && git push origin v1.2.3`

Commit messages must use conventional prefixes (`feat:`, `fix:`, `chore:`, `docs:`, `test:`, `ci:`, `refactor:`) — GoReleaser uses them to generate the changelog.

## Troubleshooting

### Bridge Not Detected

**Safari / Firefox — "Bridge not found"**
1. Confirm the tray menu shows **✓ HTTPS Enabled**. If not, click **Enable HTTPS** and enter your system password when prompted.
2. After enabling HTTPS, **restart the Bridge** (Stop Server → Start Server) so it picks up the new certs.
3. Make sure you are visiting `https://continuata.io` (HTTPS), not HTTP.
4. Try quitting and relaunching the Bridge entirely.

**Chrome — not detected**
- Chrome does not need the Bridge (it uses the File System Access API directly).
- If detection still fails, check that nothing else is using port 8765: `lsof -i :8765`.

### Download Fails or Stalls

1. Check the tray status — if it shows an error, quit and relaunch.
2. Verify the download path has write permissions.
3. Confirm available disk space.
4. Cancel (`POST /cancel`) and retry from the website.

### Platform-Specific

**macOS — "App is damaged" / Gatekeeper**
- Right-click the app and choose **Open** on first launch.
- Or: `xattr -dr com.apple.quarantine continuata-bridge`

**Windows — SmartScreen warning**
- Click **More info** → **Run anyway** on first launch.

**Linux — no tray icon**
- Ensure a system tray / status-notifier implementation is running (e.g., `gnome-shell-extension-appindicator` on GNOME).
- Wayland: set `GDK_BACKEND=x11` if the icon doesn't appear.

## License

MIT — see [LICENSE](LICENSE) for details.
